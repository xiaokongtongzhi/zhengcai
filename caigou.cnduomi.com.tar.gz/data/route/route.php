<?php	return array (
  'find_password$.' => 'user/Login/findPassword',
);