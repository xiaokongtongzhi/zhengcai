<?php
 return array(
 	'zs_url'=>'http://222.143.21.205:8091/wsscservices_test/services/wsscWebService?wsdl',
 );