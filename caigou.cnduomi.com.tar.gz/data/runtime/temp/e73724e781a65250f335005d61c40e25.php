<?php /*a:2:{s:86:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/index.html";i:1589957591;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">商品列表</a></li>
    </ul>
    <form class="well form-inline margin-top-20" method="post" action="<?php echo url('Goods/index'); ?>">
        搜索类型:
        <select class="form-control" name="category" id="category" style="width: 140px;">
            <option <?php echo $category==0 ? 'selected'  : ''; ?> value='0'>全部</option>
            <option <?php echo $category==1 ? 'selected'  : ''; ?> value='1'>型号</option>
            <option <?php echo $category==2 ? 'selected'  : ''; ?> value='2'>品牌</option>
            <option <?php echo $category==3 ? 'selected'  : ''; ?> value='3'>类别</option>
            <!-- <option value='0'>全部</option> -->
            <!-- <option value='0'>全部</option> -->
        </select> &nbsp;&nbsp;
        关键字:
        <input type="text" class="form-control" id="keyword" name="keyword" style="width: 200px;"
               value="<?php echo (isset($keyword) && ($keyword !== '')?$keyword:''); ?>" placeholder="请输入型号/品牌/类别">
        <input type="submit" class="btn btn-primary" value="搜索"/>
        <a class="btn btn-danger" href="<?php echo url('Goods/index'); ?>">清空</a>
        <a class="btn btn-danger" id="export">导出Excel表格</a>
    </form>
    <form class="js-ajax-form" action="" method="post">
        <table class="table table-hover table-bordered table-list">
            <thead>
            <tr>
                <th width="70">ID</th>
                <!-- <th>型号编号</th> -->
                <th>型号名称</th>
                <!-- <th>品目编号</th> -->
                <th>品目名称</th>
                <!-- <th>品牌编号</th> -->
                <th>品牌名称</th>
                <!-- <th>类别编号</th> -->
                <th>类别名称</th>
                <th>配件信息</th>
                <th>增值服务</th>
                <th width="80">入库状态</th>
                <th width="80">是否报价</th>
                <th width="150">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                <tr>
                    <td><b><?php echo $vo['id']; ?></b></td>
                    <!-- <td>
                        <?php echo $vo['xhbh']; ?>
                    </td> -->
                    <td title='<?php echo $vo['xhbh']; ?>'>
                        <?php echo $vo['xhmc']; ?>
                    </td>
                    <!-- <td><?php echo $vo['pmbh']; ?></td> -->
                    <td title='<?php echo $vo['pmbh']; ?>'><?php echo $vo['pmmc']; ?></td>
                    <!-- <td>
                        <?php echo $vo['ppbh']; ?>
                    </td> -->
                    <td title='<?php echo $vo['ppbh']; ?>'>
                        <?php echo $vo['ppmc']; ?>
                    </td>
                    <!-- <td>
                        <?php echo $vo['lbbh']; ?>

                    </td> -->
                    <td title='<?php echo $vo['lbbh']; ?>'>
                        <?php echo $vo['lbmc']; ?>
                    </td>
                    <td>
                        <?php if(!(empty($vo['parts']) || (($vo['parts'] instanceof \think\Collection || $vo['parts'] instanceof \think\Paginator ) && $vo['parts']->isEmpty()))): ?>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/parts',array('id'=>$vo['id'])); ?>','配置信息')">查看详情</a>
                        <?php else: ?>
                            暂无配置信息
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!(empty($vo['service']) || (($vo['service'] instanceof \think\Collection || $vo['service'] instanceof \think\Paginator ) && $vo['service']->isEmpty()))): ?>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/service',array('id'=>$vo['id'])); ?>','增值服务')">查看详情</a>
                        <?php else: ?>
                            暂无增值服务
                        <?php endif; ?>
                        
                    </td>
                    <td>
                        <?php switch($vo['spzt']): case "0": ?>初始化<?php break; case "1": ?>待审核<?php break; case "2": ?>上线<?php break; case "3": ?>下线<?php break; case "4": ?>已删除<?php break; case "5": ?>审核不通过<?php break; ?>
						<?php endswitch; ?>
                    </td>
                    <td>
                        <?php echo !empty($vo['quote_status']) ? '是' : '否'; ?>
                    </td>
                    <td>
                        <a class="btn btn-xs btn-danger" href="<?php echo url('Goods/info',array('id'=>$vo['id'])); ?>">查看详情</a>
                        <a class="btn btn-xs btn-danger" href="<?php echo url('Mall/shangjia',array('id'=>$vo['id'])); ?>">上架本地商城</a>
						 <a class="btn btn-xs btn-danger" href="javascript:openIframeDialog('<?php echo url('Goods/info',array('id'=>$vo['id'],'type'=>1)); ?>','商品报价')">报价</a>
						 <!--<a class="btn btn-xs btn-danger js-ajax-dialog-btn" data-msg="确定要删除吗" href="<?php echo url('Goods/deletegoods',array('id'=>$vo['id'])); ?>">删除</a>-->
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <tfoot>
            <tr>
                <th width="70">ID</th>
                <!-- <th>型号编号</th> -->
                <th>型号名称</th>
                <!-- <th>品目编号</th> -->
                <th>品目名称</th>
                <!-- <th>品牌编号</th> -->
                <th>品牌名称</th>
                <!-- <th>类别编号</th> -->
                <th>类别名称</th>
                <th>配件信息</th>
                <th>增值服务</th>
                <th width="80">上架状态</th>
                <th width="80">是否报价</th>
                <th width="150">操作</th>
            </tr>
            </tfoot>
        </table>
        <div class="table-actions">
        </div>
        <ul class="pagination"><?php echo (isset($page) && ($page !== '')?$page:''); ?></ul>
    </form>
</div>
<script src="/static/js/admin.js"></script>
<script>

    function reloadPage(win) {
        win.location.reload();
    }

    $(function () {
        $('select[name="category"]').change(function(){
            val=$(this).val();
            if(val==0){
                $('input[name="keyword"]').attr('placeholder','请输入型号/品牌/类别');
            }else if(val==1){
                $('input[name="keyword"]').attr('placeholder','请输入型号');
            }else if(val==2){
                $('input[name="keyword"]').attr('placeholder','请输入品牌');
            }else if(val==3){
                $('input[name="keyword"]').attr('placeholder','请输入类别');
            }
        })
    });


    $('#export').click(function(){
        var category=$('#category').val()?$('#category').val():-1;
        var keyword=$('#keyword').val()?$('#keyword').val():'';
      
        
        location.href = "/admin/goods/export/category/"+category+"/keyword/"+keyword;
    })
    
</script>
</body>
</html>