<?php /*a:2:{s:85:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/order/info.html";i:1590022022;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
	<div class="wrap">
		<ul class="nav nav-tabs">
			<li><a href="javascript:;" onclick="history.go(-1)">订单列表</a></li>
			<li class="active"><a >订单详情</a></li>
		</ul>
		<?php $status = array('0'=>'待确认','1'=>'待送货','2'=>'待收货','3'=>'待开票','4'=>'待收款','5'=>'已完成','10'=>'已拒绝','11'=>'已取消'); ?>
		<form method="post" class="form-horizontal js-ajax-form margin-top-20" action="<?php echo url('order/wuliupost'); ?>">
			<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
			  	<tr>
				   <td><b>送货城市</b></td><td><?php echo $data['deliverycity']; ?></td>
				   <td><b>送货区/县</b></td><td><?php echo $data['deliverycounty']; ?></td>
				   <td><b>送货地址</b></td><td><?php echo $data['shdd']; ?></td>
				   <td><b>订单编号</b></td><td><?php echo $data['ddbh']; ?></td>
				 </tr>
			  	<tr>
			   		<td><b>采购人名称</b></td><td><?php echo $data['cgrmc']; ?></td>
			   		<td><b>需方联系人</b></td><td><?php echo $data['xflxrxm']; ?></td>
			   		<td><b>需方电话</b></td><td><?php echo $data['xfdh']; ?></td>
			   		<td><b>电商名称</b></td><td><?php if(!empty($data['ghsmc'])): ?><?php echo $data['ghsmc']; ?><?php endif; ?></td>
			  	</tr>
			  	<tr>
			   		<td><b>订单金额</b></td>
			   		<td>
			   			<?php if(!empty($data['ddze'])): ?><?php echo $data['ddze']; ?><?php endif; ?>
			   		</td>
			   		<td><b>订单提交时间</b></td>
			   		<td>
			   			<?php if(!empty($data['cjrq'])): ?><?php echo $data['cjrq']; ?><?php endif; ?>
			   		</td>
			   		<td><b>订单状态</b></td>
			   		<td><?php echo $status[$info['status']]; ?>
					</td>
			   		<td><b>支付方式</b></td>
			   		<td>
			   			<?php if(!empty($data['zffs'])): if($data['zffs'] == 70080001): ?>现金<?php endif; if($data['zffs'] == 70080002): ?>公务卡结算<?php endif; if($data['zffs'] == 70080003): ?>银行转账<?php endif; if($data['zffs'] == 70080004): ?>银行支票<?php endif; ?>
							
							<?php endif; ?>
						</div>
			   		</td>
			  	</tr>

			  	<tr>
			   		<td><b>发票抬头</b></td>
			   		<td>
			   			<?php if(!empty($data['fptt'])): ?>
						<?php echo $data['fptt']; ?>
						<?php endif; ?>
			   		</td>
			   		<td><b>发票内容</b></td>
			   		<td>
			   			<?php if(!empty($data['fpnr'])): if($data['fpnr'] == 70100001): ?>商品明细<?php endif; if($data['fpnr'] == 70100002): ?>办公耗材<?php endif; if($data['fpnr'] == 70100003): ?>办公用品<?php endif; ?>	
						<?php endif; ?>
			   		</td>
			   		<td><b>纳税人识别号</b></td>
			   		<td>
				   		<?php if(!empty($data['nsrsbh'])): ?>
							<?php echo $data['nsrsbh']; ?>
						<?php endif; ?>
					</td>
			   		<td><b>是否需要安装服务</b></td>
			   		<td>
			   			<?php if(!empty($data['sfxyazfw'])): if($data['sfxyazfw'] == 0): ?>需要安装服务<?php endif; if($data['sfxyazfw'] == 1): ?>不需要安装服务<?php endif; ?>
						<?php endif; ?>
			   		</td>
			  	</tr>
			  	<tr>
			   		<td><b>订单备注说明</b></td>
			   		<td>
			   			<?php if(!empty($data['beiz'])): ?>
							<?php echo $data['beiz']; ?>
						<?php endif; ?>
			   		</td>
			   		<td><b>收货时间</b></td>
			   		<td>
			   			<?php if(!empty($data['shsj'])): if($data['shsj'] == 0): ?>工作日/周末/假日均可<?php endif; if($data['shsj'] == 1): ?>周末送货<?php endif; if($data['shsj'] == 2): ?>工作日送货<?php endif; ?>	
						<?php endif; ?>
			   		</td>
			   		<td><b>收货期限</b></td>
			   		<td>
				   		<?php if(!empty($data['shqx'])): if($data['shqx'] == 0): ?>不限<?php endif; if($data['shqx'] == 1): ?>一天内<?php endif; if($data['shqx'] == 2): ?>两天内<?php endif; if($data['shqx'] == 3): ?>三天内<?php endif; if($data['shqx'] == 5): ?>五天内<?php endif; if($data['shqx'] == 7): ?>七天内<?php endif; ?>

						<?php endif; ?>
					</td>
					<td><b>政采状态</b></td>
			   		<td><?php if(!(empty($data['zt']) || (($data['zt'] instanceof \think\Collection || $data['zt'] instanceof \think\Paginator ) && $data['zt']->isEmpty()))): if($data['zt'] == 2): ?>供应商待确认<?php endif; if($data['zt'] == 3): ?>待验收<?php endif; if($data['zt'] == 4): ?>订单已取消<?php endif; if($data['zt'] == 5): ?>验收通过<?php endif; if($data['zt'] == 8): ?>电商作废<?php endif; if($data['zt'] == 9): ?>采购单位确认作废<?php endif; ?>
				   		<?php endif; ?>
					</td>
			   		
			  	</tr>
			</table>
			<br/><br/>
	
			
			<div class="wrap js-check-wrap">
				<form class="js-ajax-form" action="" method="post">
					<table class="table table-hover table-bordered table-list">
						<thead>
						<tr>
							<th>型号编号</th>
							<th>型号名称</th>
							<th>品牌编号</th>
							<th>品牌名称</th>
							<th>配件信息</th>
							<th>购买数量</th>
							<th>商品的实际价格</th>
							<th>小计</th>
							<th>操作</th>
						</tr>
						</thead>
						<?php if(is_array($data['productList']) || $data['productList'] instanceof \think\Collection || $data['productList'] instanceof \think\Paginator): if( count($data['productList'])==0 ) : echo "" ;else: foreach($data['productList'] as $key=>$v): ?>
							<tr>
								<td><?php echo $v['XHBH']; ?></td>
								<td><?php if(!(empty($v['XHMC']) || (($v['XHMC'] instanceof \think\Collection || $v['XHMC'] instanceof \think\Paginator ) && $v['XHMC']->isEmpty()))): ?><?php echo $v['XHMC']; ?><?php endif; ?></td>
								<td><?php echo $v['PPBH']; ?></td>
								<td><?php echo $v['PPMC']; ?></td>
								<td>
								<?php if(!(empty($v['accessoryList']) || (($v['accessoryList'] instanceof \think\Collection || $v['accessoryList'] instanceof \think\Paginator ) && $v['accessoryList']->isEmpty()))): ?>
									<table class="table table-hover table-bordered table-list">
										<thead>
											<tr>
												<th>配件名称</th>
												<th>配件单价</th>
												<th>数量</th>
											</tr>
										</thead>
										<?php if(is_array($v['accessoryList']) || $v['accessoryList'] instanceof \think\Collection || $v['accessoryList'] instanceof \think\Paginator): if( count($v['accessoryList'])==0 ) : echo "" ;else: foreach($v['accessoryList'] as $key=>$vo): ?>
											<tr>
												<td><?php echo $vo['PJMC']; ?></td>
												<td><?php echo $vo['PJJG']; ?>元</td>
												<td><?php echo $vo['SL']; ?></td>
											</tr>
										<?php endforeach; endif; else: echo "" ;endif; ?>	
									</table>
									<?php endif; ?>
								</td>
								<td><?php echo $v['SL']; ?></td>
								<td><?php echo $v['SJJG']; ?>元</td>
								<td><?php echo $v['XJJG']; ?>元</td>
								<td><a href="<?php echo url('Order/shibiema',array('xhbh'=>$v['XHBH'],'ddbh'=>$data['ddbh'],'xhmc'=>$v['XHMC'],)); ?>">推送识别码</a>
								<?php $count=db("biaoshima")->where(['ddbh'=>$data['ddbh'],'xhbh'=>$v['XHBH']])->count(); ?>
								已推送<?php echo $count; ?>次
								</td>
							</tr>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</table>
				</form>
			</div>
			<p>推送信息记录</p>
			<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
			  	<tr>
				   <td><b>物流是否拆单</b></td><td><?php if($wuliu['sfcd']==1): ?>不拆单<?php else: ?>拆单<?php endif; ?></td>
				   <td><b>分拆子订单编号</b></td><td><?php echo $wuliu['fczddbh']; ?></td>
				   <td><b>快递公司</b></td><td><?php echo $wuliu['kdgs']; ?></td>
				   <td><b>快递单号</b></td><td><?php echo $wuliu['kddh']; ?></td>
				 </tr>
			  	<tr>
			   		<td><b>描述</b></td><td><?php echo $wuliu['ms']; ?></td>
			   		<td><b>快递时间</b></td><td><?php echo $wuliu['kdsj']; ?></td>
			   		<td><b>收货时间</b></td><td><?php echo $qianshou['shsj']; ?></td>
			   		<td><b>发票开具时间</b></td><td><?php echo $qianshou['fpkjsj']; ?></td>
			  	</tr>
				<tr>
			   		<td><b>收到发票时间</b></td><td><?php echo $qianshou['fpsdsj']; ?></td>
			   		<td><b>收款标志</b></td><td><?php if($qianshou['skbz']==1): ?>正常收款<?php else: ?>未收款<?php endif; ?></td>
			   		<td><b>收款金额</b></td><td><?php echo $qianshou['skje']; ?></td>
			   		<td><b>收款时间</b></td><td><?php echo $qianshou['sksj']; ?></td>
			  	</tr>
			</table>
			<p>操作记录</p>
			<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
			  	<tr>
				   <td><b>栏目</b></td>
				   <td><b>操作项</b></td>
				   <td><b>时间</b></td>
				 </tr>
				 <?php if(is_array($orderlog) || $orderlog instanceof \think\Collection || $orderlog instanceof \think\Paginator): if( count($orderlog)==0 ) : echo "" ;else: foreach($orderlog as $key=>$vo): ?>
			  	<tr>
					<td><?php echo $vo['catename']; ?></td>
					<td><?php echo $vo['name']; ?></td>
					<td><?php echo date('Y-m-d H:i:s',$vo['addtime']); ?></td>
			  	</tr>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</table>
		</form>
	</div>
	<script src="/static/js/admin.js"></script>
</body>
</html>