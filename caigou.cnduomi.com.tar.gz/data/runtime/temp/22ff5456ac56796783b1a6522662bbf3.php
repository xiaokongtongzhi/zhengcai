<?php /*a:2:{s:86:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/parts.html";i:1570685535;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
<div class="wrap js-check-wrap">
    <form class="js-ajax-form" action="" method="post">
        <table class="table table-hover table-bordered table-list">
            <thead>
            <tr>
                <th width="70">ID</th>
                <!-- <th>型号编号</th> -->
                <!-- <th>型号名称</th> -->
                <!-- <th>品目编号</th> -->
                <th>品目名称</th>
                <!-- <th>品牌编号</th> -->
                <!-- <th>配件编号</th> -->
                <!-- <th>类别编号</th> -->
                
                <th>配件名称</th>
                <th>配件描述</th>
                <!-- <th>配件明细</th> -->
                <th width="80">上架状态</th> 
                <th width="80">是否报价</th>
                <!--<?php if(!(empty($type) || (($type instanceof \think\Collection || $type instanceof \think\Paginator ) && $type->isEmpty()))): ?>-->
                    <th>报价</th>
                   <!-- <?php else: ?>
                    <th>配件明细</th>
                <?php endif; ?>-->
               <th width="150">操作</th>
            </tr>
            </thead>
            <?php if(is_array($parts) || $parts instanceof \think\Collection || $parts instanceof \think\Paginator): if( count($parts)==0 ) : echo "" ;else: foreach($parts as $key=>$vo): ?>
                <tr>
                    <td><b><?php echo $vo['id']; ?></b></td>
                    <!--<td><?php echo $vo['pmbh']; ?></td>-->
                    <td><?php echo $vo['pmmc']; ?></td>
                    <!--<td><?php echo $vo['PJBH']; ?></td>-->
                    <td><?php echo $vo['PJMC']; ?></td>
                    <td>
                        <?php echo $vo['PJMS']; ?>
                    </td>
                    <td>
					  <?php if($vo['zt'] == '2'): ?>
					  下架
					  <?php else: ?>
					  上架
					  <?php endif; ?>
                    </td>
                    <td>
                        <?php echo !empty($vo['quote_status']) ? '是' : '否'; ?>
                    </td>
					 <td>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/parts_info',array('id'=>$vo['id'],'type'=>1)); ?>','报价')">报价</a>
							<?php if($vo['quote_status'] == 1): ?>
								<a href="javascript:openIframeDialog('<?php echo url('Goods/parts_offer',array('id'=>$vo['id'])); ?>','报价记录')">报价记录</a>
							<?php endif; ?>
							 <a href="<?php echo url('Goods/peijianshangjia',array('id'=>$vo['id'])); ?>">上架</a>
							<a href="<?php echo url('Goods/peijianxiajia',array('id'=>$vo['id'])); ?>">下架</a> 
                        </td>
                     <!--<?php if(!(empty($type) || (($type instanceof \think\Collection || $type instanceof \think\Paginator ) && $type->isEmpty()))): ?>-->
                       
                      <!--  <?php else: ?>
                        <td>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/parts_info',array('id'=>$vo['id'])); ?>','配件明细')">查看</a>
							<?php if($vo['quote_status'] == 1): ?>
								<a href="javascript:openIframeDialog('<?php echo url('Goods/parts_offer',array('id'=>$vo['id'])); ?>','报价记录')">报价记录</a>
							<?php endif; ?>
                        </td>
                    <?php endif; ?>-->
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <div class="table-actions">
        </div>
        <ul class="pagination"><?php echo (isset($page) && ($page !== '')?$page:''); ?></ul>
    </form>
</div>
<script src="/static/js/admin.js"></script>
<script>

    function reloadPage(win) {
        win.location.reload();
    }

    $(function () {
        $('select[name="category"]').change(function(){
            val=$(this).val();
            if(val==0){
                $('input[name="keyword"]').attr('placeholder','请输入型号/品牌/类别');
            }else if(val==1){
                $('input[name="keyword"]').attr('placeholder','请输入型号');
            }else if(val==2){
                $('input[name="keyword"]').attr('placeholder','请输入品牌');
            }else if(val==3){
                $('input[name="keyword"]').attr('placeholder','请输入类别');
            }
        })
    });
</script>
</body>
</html>