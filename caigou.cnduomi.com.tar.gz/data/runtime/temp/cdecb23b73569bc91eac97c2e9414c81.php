<?php /*a:2:{s:85:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/info.html";i:1589957591;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
<style type="text/css">
    .form-group .control-label{
        padding-top: 0;
    }
</style>
</head>
<body>
<div class="wrap js-check-wrap">
	<?php if(empty($type) || (($type instanceof \think\Collection || $type instanceof \think\Paginator ) && $type->isEmpty())): ?>
        <ul class="nav nav-tabs">
            <li><a href="<?php echo url('Goods/index'); ?>">商品列表</a></li>
            <li class="active"><a href="#">商品详情</a></li>
        </ul>
    <?php endif; ?>
	<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
		<tr>
			<td><b>类别名称</b></td><td><?php echo $info['lbmc']; ?></td>
			<td><b>品目名称</b></td><td><?php echo $info['pmmc']; ?></td>
			<td><b>品牌名称</b></td><td><?php echo $info['ppmc']; ?></td>
			<td><b>型号名称</b></td><td><?php echo $info['xhmc']; ?></td>
		</tr>
		<tr>
			<td><b>当前报价</b></td><td><?php echo $info['quote_price']; ?></td>
			<td><b>商品地址</b></td><td><a href="<?php echo $info['goods_url']; ?>" target="_blank" ><?php echo $info['goods_url']; ?></a></td>
			<td><b>品目编号</b></td><td><?php echo $info['pmbh']; ?></td>
			<td><b>品牌编号</b></td><td><?php echo $info['ppbh']; ?></td>
		</tr>
		<tr>
			<td><b>上架状态</b></td><td><?php echo $info['zt']==2 ? '上线' : '未上线'; ?></td>
			<td><b>类别编号</b></td><td><?php echo $info['lbbh']; ?></td>
			<td><b>型号编号</b></td><td><?php echo $info['xhbh']; ?></td>
			<td><b>入库状态</b></td><td>
                        <?php switch($info['spzt']): case "0": ?>初始化<?php break; case "1": ?>待审核<?php break; case "2": ?>上线<?php break; case "3": ?>下线<?php break; case "4": ?>已删除<?php break; case "5": ?>审核不通过<?php break; ?>
						<?php endswitch; ?></td>
		</tr>
	</table>
	<div style="margin-top:40px;">
		<h4>商品对应的参数列表信息</h4>
		<table class="table table-hover table-bordered table-list" >
			<?php 
				$parametersList=json_decode($info['parametersList'],true);
			 ?>
			<thead>
			<tr>
				<?php if(is_array($parametersList) || $parametersList instanceof \think\Collection || $parametersList instanceof \think\Paginator): if( count($parametersList)==0 ) : echo "" ;else: foreach($parametersList as $key=>$vo): ?>
					<th><?php echo $vo['cssm']; ?></th>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</tr>
			</thead>
			<tr>
				<?php if(is_array($parametersList) || $parametersList instanceof \think\Collection || $parametersList instanceof \think\Paginator): if( count($parametersList)==0 ) : echo "" ;else: foreach($parametersList as $key=>$vo): ?>
				<td><?php echo $vo['csz']; ?></td>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</tr>
		</table>
	</div>
	
	<form action="<?php echo url('goods/goods_quote_post',array('id'=>$info['id'])); ?>" method="post" class="form-horizontal js-ajax-form margin-top-20">
		<input type="hidden" name='id' value="<?php echo $info['id']; ?>">
		<?php if(!(empty($type) || (($type instanceof \think\Collection || $type instanceof \think\Paginator ) && $type->isEmpty()))): ?>
			<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
				<tr>
					<td><b>报价<span style="color:red;">*</span></b></td><td><input type="text" class="form-control" name="price" value="<?php if(empty($info['quote_price'])): ?><?php echo $info['price']; else: ?><?php echo $info['quote_price']; ?><?php endif; ?>"></td>
				</tr>
              <tr>
					<td><b>自有价格<span style="color:red;">*</span></b></td><td><input type="text" class="form-control" name="zyjg" value="<?php echo $info['zyjg']; ?>" placeholder="自有商城改商品价格"/></td>
				</tr>
				<tr>
					<td><b>商品地址<span style="color:red;">*</span></b></td><td><input type="text" class="form-control" name="goods_url" value="<?php echo $info['goods_url']; ?>"></td>
				</tr>
				<tr>
					<td><b>报价说明<span style="color:red;">*</span></b></td><td><textarea class="form-control" name="jgsfyy"></textarea></td>
				</tr>
				<tr>
					<td><b>服务承诺</b></td><td><textarea class="form-control" name="fwcn"></textarea></td>
				</tr>
			</table>
		<?php endif; ?>
        <div class="form-group" style="margin-top:20px;">
            <div class="col-sm-offset-2 col-sm-10">
                <?php if(!(empty($type) || (($type instanceof \think\Collection || $type instanceof \think\Paginator ) && $type->isEmpty()))): ?>
                    <button class="btn btn-success js-ajax-submit" type="submit"><?php echo lang('提交'); ?></button>
                <?php endif; ?>
                <a class="btn btn-default" href="javascript:history.go(-1);"><?php echo lang('BACK'); ?></a>
            </div>
        </div>
    </form>
	
</div>

<script type="text/javascript" src="/static/js/admin.js"></script>

</body>
</html>
