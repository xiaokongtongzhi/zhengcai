<?php /*a:2:{s:90:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/goods_get.html";i:1577414271;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">商品获取</a></li>
    </ul>
    <form class="well form-inline margin-top-20" method="post" action="<?php echo url('Goods/goods_get_post'); ?>">
        
        开始时间:
        <input type="date" class="form-control" id="starttime" name="starttime" style="width: 200px;"
               value="<?php echo (isset($starttime) && ($starttime !== '')?$starttime:''); ?>">
	    结束时间:
        <input type="text" class="form-control" id="endtime" name="endtime" style="width: 200px;"
               value="<?php echo (isset($endtime) && ($endtime !== '')?$endtime:''); ?>" disabled>
        <input type="submit" class="btn btn-primary" value="搜索"/>
        <a class="btn btn-danger" href="<?php echo url('Goods/goods_get'); ?>">清空</a>
    </form>
	<form class="well form-inline margin-top-20" method="post" action="<?php echo url('Goods/goods_getdetail_post'); ?>">
        
        商品型号编号:
        <input type="text" class="form-control" id="xhbh" name="xhbh" style="width: 200px;"
               value="<?php echo (isset($xhbh) && ($xhbh !== '')?$xhbh:''); ?>">
	   
        <input type="submit" class="btn btn-primary" value="搜索"/>
        <a class="btn btn-danger" href="<?php echo url('Goods/goods_get'); ?>">清空</a>
    </form>
</div>
<script src="/static/js/admin.js"></script>
<script>

    function reloadPage(win) {
        win.location.reload();
    }

    $("#starttime").bind('input propertychange',function(){
				var val=$(this).val();
				var oldTime = (new Date(val)).getTime(); //得到毫秒数
				var newmite= oldTime+86400000;//86400000是1天
				var endTime=$("#endtime").val();
				var newTime3 = new Date(newmite);//参数是毫秒类型 可以不带参数 就是获取当前时间  传参数就是把毫秒装换成时间类型  
				var aa=gshtime(newTime3);
				var date= new Date(Date.parse(aa.replace(/-/g,  "/")));  
				$("#endtime").val(formatDate(date));
			});
			function formatDate(date){  
			    var y = date.getFullYear();  
			    var m = date.getMonth() + 1;  
			    m = m < 10 ? '0' + m : m;  
			    var d = date.getDate();  
			    d = d < 10 ? ('0' + d) : d;  
			    return y + '-' + m + '-' + d;  
			};  
			function gshtime(time)  
		      {   
		          var year = time.getFullYear();
		          var month = time.getMonth() + 1;    
		          var day = time.getDate();         
		          var hh = time.getHours();       
		          var mm = time.getMinutes();    
		          var str= year + "-";  
		          if(month < 10)  
		             str+= "0";  
		          str+= month + "-";  
		          if(day < 10)  
		              str+= "0";  
		          str+= day + " ";  
		          return(str);   
		      }  
</script>
</body>
</html>