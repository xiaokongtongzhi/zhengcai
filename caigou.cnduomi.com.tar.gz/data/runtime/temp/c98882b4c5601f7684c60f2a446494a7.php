<?php /*a:1:{s:93:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/find_sp_sfbj.html";i:1587517419;}*/ ?>
<div style="margin-top:50px;margin-left:50px;">成功标识:<?php echo $result['resultFlag']; ?><br>提示信息：<?php echo $result['resultMessage']; ?><br>商品价格：<?php echo $result['spjg']; ?>元<br>
商品入库时间：<?php echo $result['sprksj']; ?></div>