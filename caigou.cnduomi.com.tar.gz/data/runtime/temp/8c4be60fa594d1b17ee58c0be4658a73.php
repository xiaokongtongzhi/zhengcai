<?php /*a:2:{s:95:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/goods_get_post.html";i:1576222150;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">商品获取</a></li>
    </ul>
   
	<notempty  name="list">
    <form class="js-ajax-form" action="" method="post">
        <table class="table table-hover table-bordered table-list">
            <thead>
            <tr>
                <!-- <th>型号编号</th> -->
                <th>型号名称</th>
                <!-- <th>品目编号</th> -->
                <th>品目名称</th>
                <!-- <th>品牌编号</th> -->
                <th>品牌名称</th>
                <!-- <th>类别编号</th> -->
                <th>类别名称</th>
                <th>配件信息</th>
                <th>增值服务</th>
                <th width="80">上架状态</th>
                <th width="80">是否报价</th>
                <th width="150">操作</th>
            </tr>
            </thead>
            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                <tr>
                    <!-- <td>
                        <?php echo $vo['xhbh']; ?>
                    </td> -->
                    <td title='<?php echo $vo['xhbh']; ?>'>
                        <?php echo $vo['xhmc']; ?>
                    </td>
                    <!-- <td><?php echo $vo['pmbh']; ?></td> -->
                    <td title='<?php echo $vo['pmbh']; ?>'><?php echo $vo['pmmc']; ?></td>
                    <!-- <td>
                        <?php echo $vo['ppbh']; ?>
                    </td> -->
                    <td title='<?php echo $vo['ppbh']; ?>'>
                        <?php echo $vo['ppmc']; ?>
                    </td>
                    <!-- <td>
                        <?php echo $vo['lbbh']; ?>

                    </td> -->
                    <td title='<?php echo $vo['lbbh']; ?>'>
                        <?php echo $vo['lbmc']; ?>
                    </td>
                    <td>
                        <?php if(!(empty($vo['parts']) || (($vo['parts'] instanceof \think\Collection || $vo['parts'] instanceof \think\Paginator ) && $vo['parts']->isEmpty()))): ?>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/parts',array('id'=>$vo['id'],'type'=>1)); ?>','配置信息')">查看详情</a>
                        <?php else: ?>
                            暂无配置信息
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(!(empty($vo['service']) || (($vo['service'] instanceof \think\Collection || $vo['service'] instanceof \think\Paginator ) && $vo['service']->isEmpty()))): ?>
                            <a href="javascript:openIframeDialog('<?php echo url('Goods/service',array('id'=>$vo['id'],'type'=>1)); ?>','增值服务')">查看详情</a>
                        <?php else: ?>
                            暂无增值服务
                        <?php endif; ?>
                        
                    </td>
                    <td>
                        <?php if($vo['zt'] == '2'): ?>
                            <a data-toggle="tooltip" title="上线"><i class="fa fa-check"></i></a>
                            <?php else: ?>
                            <a data-toggle="tooltip" title="未上线"><i class="fa fa-close"></i></a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo !empty($vo['quote_status']) ? '是' : '否'; ?>
                    </td>
                    <td>
                        
                        
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <tfoot>
            <tr>
                <th width="70">ID</th>
                <!-- <th>型号编号</th> -->
                <th>型号名称</th>
                <!-- <th>品目编号</th> -->
                <th>品目名称</th>
                <!-- <th>品牌编号</th> -->
                <th>品牌名称</th>
                <!-- <th>类别编号</th> -->
                <th>类别名称</th>
                <th>配件信息</th>
                <th>增值服务</th>
                <th width="80">商品状态</th>
                <th width="80">是否报价</th>
                <th width="150">操作</th>
            </tr>
            </tfoot>
        </table>
        <div class="table-actions">
        </div>
        
    </form>
	</notempty >
</div>
<script src="/static/js/admin.js"></script>
<script>

    function reloadPage(win) {
        win.location.reload();
    }

    $("#starttime").bind('input propertychange',function(){
				var val=$(this).val();
				var oldTime = (new Date(val)).getTime(); //得到毫秒数
				var newmite= oldTime+86400000*7;//86400000是1天
				var endTime=$("#endtime").val();
				var newTime3 = new Date(newmite);//参数是毫秒类型 可以不带参数 就是获取当前时间  传参数就是把毫秒装换成时间类型  
				var aa=gshtime(newTime3);
				var date= new Date(Date.parse(aa.replace(/-/g,  "/")));  
				$("#endtime").val(formatDate(date));
			});
			function formatDate(date){  
			    var y = date.getFullYear();  
			    var m = date.getMonth() + 1;  
			    m = m < 10 ? '0' + m : m;  
			    var d = date.getDate();  
			    d = d < 10 ? ('0' + d) : d;  
			    return y + '-' + m + '-' + d;  
			};  
			function gshtime(time)  
		      {   
		          var year = time.getFullYear();
		          var month = time.getMonth() + 1;    
		          var day = time.getDate();         
		          var hh = time.getHours();       
		          var mm = time.getMinutes();    
		          var str= year + "-";  
		          if(month < 10)  
		             str+= "0";  
		          str+= month + "-";  
		          if(day < 10)  
		              str+= "0";  
		          str+= day + " ";  
		          return(str);   
		      }  
</script>
</body>
</html>