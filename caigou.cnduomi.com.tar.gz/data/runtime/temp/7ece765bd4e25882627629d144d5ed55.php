<?php /*a:2:{s:85:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/order/over.html";i:1569571959;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">已完成订单列表</a></li>
    </ul>
     <form class="well form-inline margin-top-20" method="post" action="<?php echo url('order/over'); ?>">
       联系人:
        <input type="text" class="form-control" id="keyword" name="keyword" style="width: 200px;"
               value="<?php echo (isset($keyword) && ($keyword !== '')?$keyword:''); ?>" placeholder="请输入联系人">
        联系电话:
        <input type="text" class="form-control" id="tel" name="tel" style="width: 200px;"
               value="<?php echo (isset($tel) && ($tel !== '')?$tel:''); ?>" placeholder="请输入联系电话">
        提交时间:
        <input type="text" class="form-control js-bootstrap-datetime" name="start_time"
               value="<?php echo (isset($start_time) && ($start_time !== '')?$start_time:''); ?>"
               style="width: 140px;" autocomplete="off">-
        <input type="text" class="form-control js-bootstrap-datetime" name="end_time"
               value="<?php echo (isset($end_time) && ($end_time !== '')?$end_time:''); ?>"
               style="width: 140px;" autocomplete="off"> &nbsp; &nbsp;
        <input type="submit" class="btn btn-primary" value="搜索"/>
        <a class="btn btn-danger" href="<?php echo url('order/over'); ?>">清空</a>
    </form>
    <form class="js-ajax-form" action="" method="post">
        <table class="table table-hover table-bordered table-list">
            <thead>
            <tr>
                <th width="70">ID</th>
				<th>订单编号</th>
                <th>送货城市</th>
                <th>送货区/县</th>
                <th>采购人名称</th> 
                <th>需方联系人</th>
                <th>需方电话</th>
                <th>电商名称</th>
                <th>订单金额</th>
                <th>订单提交时间</th>
                <th>订单状态</th>
                <th width="">支付方式</th>
                <th width="">操作</th>
            </tr>
            </thead>
            <?php $status = array('0'=>'待确认','1'=>'待送货','2'=>'待收货','3'=>'待开票','4'=>'待收款','5'=>'已完成','10'=>'已拒绝'); if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $key=>$vo): ?>
                <tr>
                    <td><b><?php echo $vo['id']; ?></b></td>
                    <td>
                        <?php echo $vo['ddbh']; ?>
                    </td> 
                    <td >
                        <?php echo $vo['deliverycity']; ?>
                    </td>
					<td><?php echo $vo['deliverycounty']; ?></td> 
                    <td title='<?php echo $vo['cgrmc']; ?>'><?php echo $vo['cgrmc']; ?></td>
                   <td>
                        <?php echo $vo['xflxrxm']; ?>
                    </td> 
                    <td title='<?php echo $vo['xfdh']; ?>'>
                        <?php echo $vo['xfdh']; ?>
                    </td>
                    <td>
                        <?php echo $vo['ghsmc']; ?>

                    </td>
                    <td title='<?php echo $vo['ddze']; ?>'>
                        <?php echo $vo['ddze']; ?>
                    </td>
                    <td>
                       <?php echo $vo['cjrq']; ?>
                    </td>
                    <td>
                       <?php echo $status[$vo['status']]; ?> 
                    </td>
					<td>
					<?php if($vo['zffs']=='70080001'): ?>
						现金
					<?php elseif($vo['zffs']=='70080002'): ?>
						公务卡结算
					<?php elseif($vo['zffs']=='70080003'): ?>
						银行转账
					<?php elseif($vo['zffs']=='70080004'): ?>
                        银行支票
                      <?php endif; ?>  
                    </td>
                    <td>
                        <a href="<?php echo url('Order/info',array('id'=>$vo['id'])); ?>">查看详情</a>
                    </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <tfoot>
            <tr>
                <th width="70">ID</th>
				<th>订单编号</th>
                <th>送货城市</th>
                <th>送货区/县</th>
                <th>采购人名称</th> 
                <th>需方联系人</th>
                <th>需方电话</th>
                <th>电商名称</th>
                <th>订单金额</th>
                <th>订单提交时间</th>
                <th>订单状态</th>
                <th width="">支付方式</th>
                <th width="">操作</th>
            </tr>
            </tfoot>
        </table>
        <div class="table-actions">
        </div>
        <ul class="pagination"><?php echo (isset($page) && ($page !== '')?$page:''); ?></ul>
    </form>
</div>
<script src="/static/js/admin.js"></script>
<script>

    function reloadPage(win) {
        win.location.reload();
    }

    $(function () {
        $('select[name="category"]').change(function(){
            val=$(this).val();
            if(val==0){
                $('input[name="keyword"]').attr('placeholder','请输入型号/品牌/类别');
            }else if(val==1){
                $('input[name="keyword"]').attr('placeholder','请输入型号');
            }else if(val==2){
                $('input[name="keyword"]').attr('placeholder','请输入品牌');
            }else if(val==3){
                $('input[name="keyword"]').attr('placeholder','请输入类别');
            }
        })
    });
</script>
</body>
</html>