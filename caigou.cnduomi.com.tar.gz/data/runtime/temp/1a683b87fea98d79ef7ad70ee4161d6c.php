<?php /*a:2:{s:101:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/admin/goods/goods_getdetail_post.html";i:1589341041;s:82:"/www/wwwroot/caigou.cnduomi.com/public/themes/admin_simpleboot3/public/header.html";i:1559815722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<body>
	<div class="wrap">
		<ul class="nav nav-tabs">
			<!-- <li><a href="javascript:;" onclick="history.go(-1)"></a></li> -->
			<li class="active"><a >商品型号信息以及相关报价</a></li>
		</ul>
		<?php $status = array('0'=>'待确认','1'=>'待送货','2'=>'待收货','3'=>'待开票','4'=>'待收款','5'=>'已完成','10'=>'已拒绝','11'=>'已取消'); ?>
		<form method="post" class="form-horizontal js-ajax-form margin-top-20" action="<?php echo url('order/wuliupost'); ?>">
			<table class="table table-hover table-bordered table-list" style="margin-top:20px;">
			  	<tr>
				   <td><b>型号编号</b></td><td><?php echo $result['xhbh']; ?></td>
				   <td><b>型号名称</b></td><td><?php echo $result['xhmc']; ?></td>
				   <td><b>品目编号</b></td><td><?php echo $result['pmbh']; ?></td>
				   <td><b>品目名称</b></td><td><?php echo $result['pmmc']; ?></td>
				 </tr>
			  	<tr>
			   		<td><b>品牌编号</b></td><td><?php echo $result['ppbh']; ?></td>
			   		<td><b>品牌名称</b></td><td><?php echo $result['ppmc']; ?></td>
			   		<td><b>类别编号</b></td><td><?php echo $result['lbbh']; ?></td>
			   		<td><b>类别名称</b></td><td><?php echo $result['lbmc']; ?></td>
			  	</tr>
			  	<tr>
			   		<td><b>我的报价</b></td>
			   		<td>
			   			<?php if(!empty($result['price'])): ?><?php echo $result['price']; ?><?php endif; ?>
			   		</td>
			   		<td><b>电商商品状态</b></td>
			   		<td>
			   				<?php if(!empty($result['zt'])): if($result['zt'] == 0): ?>禁用<?php endif; if($result['zt'] == 1): ?>启用<?php endif; if($result['zt'] == 2): ?>待审核<?php endif; if($result['zt'] == 3): ?>下架<?php endif; ?>
				   		
						<?php endif; ?>
			   		</td>
			   		<td><b>商品状态(厂商入库商品的状态)</b></td>
			   		<td><?php if(!empty($result['spzt'])): if($result['spzt'] == 0): ?>初始化<?php endif; if($result['spzt'] == 1): ?>待审核<?php endif; if($result['spzt'] == 2): ?>上线<?php endif; if($result['spzt'] == 3): ?>下线<?php endif; if($result['spzt'] == 4): ?>已删除<?php endif; if($result['spzt'] == 5): ?>审核不通过<?php endif; ?>
						<?php endif; ?>
					</td>
			   		<td><b>商品入库时间</b></td>
			   		<td>
			   			<?php echo $result['sprksj']; ?>
			   		</td>
			  	</tr>
				<?php if(!empty($result['parametersList'])): ?>
				<tr>
					<td colspan="2">
						<b>商品对应的参数列表信息</b>
					</td>				
					<td colspan="6">
                      <?php if(is_array($result['parametersList']) || $result['parametersList'] instanceof \think\Collection || $result['parametersList'] instanceof \think\Paginator): if( count($result['parametersList'])==0 ) : echo "" ;else: foreach($result['parametersList'] as $key=>$vo): ?>
                      <p><?php echo $vo['CSSM']; ?>----<?php echo $vo['CSZ']; ?></p>
                      <?php endforeach; endif; else: echo "" ;endif; ?>
					</td>
				</tr>
				<?php endif; if(!empty($result['accessoryList'])): ?>
				<tr>
					<td colspan="2">
						<b>商品配件</b>
					</td>				
					<td colspan="6">
					<?php if(is_array($result['accessoryList']) || $result['accessoryList'] instanceof \think\Collection || $result['accessoryList'] instanceof \think\Paginator): if( count($result['accessoryList'])==0 ) : echo "" ;else: foreach($result['accessoryList'] as $key=>$vo): ?>	
                      <p><?php echo $vo['PJBH']; ?>----<?php echo $vo['PJMC']; ?>---<?php echo $vo['ZT']; ?>----<?php echo $vo['PJJG']; ?></p>
                     <?php endforeach; endif; else: echo "" ;endif; ?>
					</td>
				</tr>
				<?php endif; if(!empty($result['serviceList'])): ?>
				<tr>
					<td colspan="2">
						<b>服务列表</b>
					</td>				
					<td colspan="6">
                      <?php if(is_array($result['serviceList']) || $result['serviceList'] instanceof \think\Collection || $result['serviceList'] instanceof \think\Paginator): if( count($result['serviceList'])==0 ) : echo "" ;else: foreach($result['serviceList'] as $key=>$vo): ?>
						<p><?php echo $vo['FWBH']; ?>----<?php echo $vo['FWMC']; ?>---<?php echo $vo['ZT']; ?>----<?php echo $vo['FWJG']; ?></p>
                      <?php endforeach; endif; else: echo "" ;endif; ?>
					</td>
				</tr>
				<?php endif; ?>
			</table>
			
		</form>
	</div>
	<script src="/static/js/admin.js"></script>
</body>
</html>