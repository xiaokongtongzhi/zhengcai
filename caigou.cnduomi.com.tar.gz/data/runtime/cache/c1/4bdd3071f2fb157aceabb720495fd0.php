<?php
//000000000000
 exit();?>
think_serialize:a:1:{s:15:"cdn_static_root";s:0:"";}