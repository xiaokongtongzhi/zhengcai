<?php
//000000000000
 exit();?>
think_serialize:a:3:{s:9:"max_files";s:2:"20";s:10:"chunk_size";s:3:"512";s:10:"file_types";a:4:{s:5:"image";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:24:"jpg,jpeg,php,png,gif,php";}s:5:"video";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:27:"mp4,avi,php,wmv,rm,rmvb,mkv";}s:5:"audio";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:15:"mp3,php,wma,wav";}s:4:"file";a:2:{s:19:"upload_max_filesize";s:5:"10240";s:10:"extensions";s:42:"txt,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,php";}}}