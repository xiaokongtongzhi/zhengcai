<?php
//000000000000
 exit();?>
think_serialize:a:3:{s:14:"admin_password";s:0:"";s:11:"admin_theme";s:17:"admin_simpleboot3";s:11:"admin_style";s:11:"orangeadmin";}