<?php
//000000000000
 exit();?>
think_serialize:a:2:{s:17:"open_registration";s:1:"0";s:16:"banned_usernames";s:0:"";}